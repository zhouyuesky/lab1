package test_for_every_dont_know;
public class test {
	public static linkList creatlnklst(String Strlst[])
	{
		linkList lnklst=new linkList();
		//lnklst.nodelst=lnklst.insertWords(" ", Strlst[0]);
		for(int i=0;i<Strlst.length-1;i++)
		{
			lnklst.insertnode(Strlst[i], Strlst[i+1]);
		}
		return lnklst;
	}
	public static void main(String[] args) {
		String str1=new String("To @ explore strange new worlds,\r\n" + 
				"To seek out new life and new civilizations?");
		String strinput="Seek to explore new and exciting synergies";
		String regex="[^\\p{Alpha}]+";
		String[] strspilt=str1.split(regex);
		linkList lnklst=creatlnklst(strspilt);
		//Node nodetmptmp=new Node(strspilt[0]);
		//for(int i=0;i<strspilt.length;i++)
		//{
		//	System.out.println(strspilt[i]);
		//}
		lnklst.searchBridgeWords("explore","worlds");
		//+"to explore the beautiful worlds and find new civilizations"
		lnklst.createNewTxtBasisOfBridgeWords(strinput);
		lnklst.shortestroad("to","new");
		return;
	}
}
