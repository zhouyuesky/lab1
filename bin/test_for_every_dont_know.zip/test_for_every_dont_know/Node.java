package test_for_every_dont_know;

public class Node {
	final static int nodeLength=10; 
	protected boolean visitflag;
	protected Node next[];		//ָ����
	protected String data,weightparent[];
	protected int weightnum[],number,visitcount;//weight ���Ը�ָ��Ĵ�������Ȩ�أ�number ��ָ��ĸ���
	public Node(String str)
	{
		this.data=str;
		number=0;
		weightnum=new int[nodeLength];
		weightparent=new String[nodeLength];
		next=new Node[nodeLength];
		visitflag=false;
		visitcount=0;
		for(int i=0;i<nodeLength;i++)
		{
			next[i]=null;
			weightnum[i]=0;
			weightparent[i]="";
		}
	}
}
